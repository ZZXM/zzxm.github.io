import lang from 'element-ui/lib/locale/lang/th' // 引入element语言包-泰语
const messages = {
  message: {
    'text': 'Good good study, Day day up'
  },
  ...lang
}

export default messages
