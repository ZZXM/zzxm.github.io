
import lang from 'element-ui/lib/locale/lang/zh-CN' // 引入element语言包
const messages = {
  message: {
    'text': '好好学习，天天向上'
  },
  ...lang
}

export default messages
