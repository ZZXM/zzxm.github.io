import lang from 'element-ui/lib/locale/lang/id' // 引入element语言包-印尼语
const messages = {
  message: {
    'text': 'Good good study, Day day up'
  },
  ...lang
}

export default messages
