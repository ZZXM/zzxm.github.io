import lang from 'element-ui/lib/locale/lang/vi' // 引入element语言包-越南语
const messages = {
  message: {
    'text': 'Good good study, Day day up'
  },
  ...lang
}

export default messages
