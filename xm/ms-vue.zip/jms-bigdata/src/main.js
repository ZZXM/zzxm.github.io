/*
 * @Date: 2020-11-03 11:13:13
 * @Author: MX
 * @Description:main
 */
import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

//引入ElementUI
import ElementUI from 'element-ui';
import('element-ui/lib/theme-chalk/index.css')
Vue.use(ElementUI);

import * as Api from '@/api'
import * as filters from '@public/utils/filters.js'

Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})

import plugins from '@public/plugins/index'
// 注册插件
plugins.install()

// Avue组件库
import Avue from './components/avuex/index'
import('./components/avuex/styles/index.scss')
Vue.use(Avue);

//引入样式
import '@/assets/style/reset.scss'
import('./assets/style/index.scss')
import('./assets/iconfont/iconfont')


Vue.prototype.$API = Api

// 设置默认皮肤
window.document.body.setAttribute('data-theme', localStorage.getItem('preTheme') ? localStorage.getItem('preTheme') + '-theme' : 'default-theme')

new Vue({
  router,
  store,
  render: function (h) { return h(App) }
}).$mount('#app')
