<!--
 * @Date: 2020-08-20 11:13:13
 * @Author: MX
 * @Description: 初始页面
-->
<template>
  <div id="app">
    <router-view/>
  </div>
</template>
<script>
export default {
  name: 'App',
  data() {
    return {

    }
  },
  methods: {
  }
}
</script>
<style lang="scss">
@import "./assets/iconfont/iconfont.css";
$bg: rgba(0, 0, 0, 0.1);
#app{
    height: 100%;
}
::-webkit-scrollbar {
  width: 10px;
  height: 10px;
}
/*滚动条小方块*/
::-webkit-scrollbar-thumb {
  background-color: $-color-icon-dark-routine;
  -webkit-border-radius: 5px; /* Safari 和 Chrome */
  -moz-border-radius: 5px; /* Firefox */
  -o-border-radius: 5px; /* Opera */
  border-radius: 5px;
}
/*滚动轨道两端按钮*/
::-webkit-scrollbar-button {
  -webkit-box-shadow: inset 0 0 5px $bg;
  background-color: $bg;
}
/*滚动轨道 内阴影*/
::-webkit-scrollbar-track {
  -webkit-box-shadow: inset 0 0 5px $bg;
  background-color: $bg;
}
</style>
