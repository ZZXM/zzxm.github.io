import Timeline from './timeline';
import TimelineItem from './timeline-item';

Timeline.Item = TimelineItem;
export default Timeline;
