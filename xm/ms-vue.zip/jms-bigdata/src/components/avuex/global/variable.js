export const KEY_COMPONENT_NAME = 'avue-';
