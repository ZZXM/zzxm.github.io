import * as Types from '../mutation-types'
let lang = localStorage.getItem('lang') || 'CN' 
const base = {
    state:{
        user: JSON.parse(localStorage.getItem('userData')) || null, // 用户信息
        token: localStorage.getItem('JT_TOKEN') || '',
        lang,// 语言
        tableHeight: 0,
        menu: JSON.parse(localStorage.getItem('MENU')) || null, // 系统菜单 
        routeAuthList: JSON.parse(localStorage.getItem('routeAuthList')) || null, // 系统菜单
        btnList:JSON.parse(localStorage.getItem('BTNLIST')) || {},//按钮
    },
    mutations:{
      // 用户信息
      [Types.SET_USER]: (state, data) => {
        state.user = data
        localStorage.setItem('userData', JSON.stringify(data))
      },
      // 用户token
      [Types.SET_TOKEN]: (state, data) => {
        state.token = data
        localStorage.setItem('JT_TOKEN', data)
      },
      // 用户系统菜单
      [Types.SET_MENU]: (state, data) => {
        state.menu = data
        localStorage.setItem('MENU', JSON.stringify(data))
      },
      // 设置按钮权限
      [Types.SET_BTNLIST]:(state,data) =>{
        state.btnList = data
        localStorage.setItem('BTNLIST', JSON.stringify(data))
      },
      // 设置页面权限
      [Types.SET_PAGELIST]:(state,data) =>{
        state.routeAuthList = data
        localStorage.setItem('routeAuthList', JSON.stringify(data))
      },
      // 退出
      [Types.LOGIN_OUT]: state => {
          // 退出登录，清楚本地缓存
          localStorage.removeItem('userData')
          localStorage.removeItem('JT_TOKEN')
          localStorage.removeItem('VISITED_VIEWS')
          localStorage.removeItem('MENU') 
          localStorage.removeItem('routeAuthList')
          localStorage.removeItem('BTNLIST')
          state.token = ''
          state.user = {}
      },
      SET_TABLE_HEIGHT: (state, data) => {
        state.tableHeight = data
      },
     
    },
    actions:{
         // 登录初始化
        [Types.LOGIN_INIT]({ commit } = {}, value) {
          console.log(value, 'value')
           const { user, token , menu, urls} = value
           commit('SET_USER', user)
           commit('SET_TOKEN', token)
           commit('SET_MENU',menu)
           commit('SET_PAGELIST',urls)
        },
        // 退出
        [Types.LOGIN_OUT]({ commit } = {}) {
              commit('LOGIN_OUT')
              commit('tags/LOGIN_OUT', {}, {root: true})
        },
        setTableHeight: ({ commit } = {}, value) => {
            commit('SET_TABLE_HEIGHT', value)
        },
        [Types.SET_BTNLIST]({ commit } = {},value) {
          commit('SET_BTNLIST', value)
      },
      [Types.SET_PAGELIST]({ commit } = {},value) {
        commit('SET_PAGELIST', value)
      }
    },
    getters: {
        user: state => state.user,
        token: state => state.token || '',
        lang: state => state.lang,
        tableHeight: state => state.tableHeight,
        menu:state => state.menu,
        btnList:state => state.btnList,
        routeAuthList:state => state.routeAuthList,
    },

    
}
export default base
