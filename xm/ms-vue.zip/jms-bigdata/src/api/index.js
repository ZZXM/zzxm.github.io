import { post, get } from '@public/http/request'

//登录
export const login = (params) => post(`/login`, params)
// export const logout = () => post(`/${APICUS}/user/logout`)

// 新闻模块
export const News = {
  reqList(params) { return post(`/newsMaintain/news`, params) }, // 新闻列表
  reqNewsDetail(params) { return post(`/adminNewsDetail`, params) }, // 新闻详情
  reqNewsAdd(params) { return post(`/newsMaintain/news/add_news`, params) }, // 添加新闻
  reqNewsDelete(params) { return post(`/adminNewsDelete`, params) }, // 删除新闻
  reqNewsModify(params) { return post(`/uploadNews`, params) }, // 修改新闻
  reqNewsUp(params) { return post(`/newsRelease`, params) }, // 新闻上线
  reqNewsDown(params) { return post(`/newsOffline`, params) }, // 新闻下线
}

// 活动模块
export const Activity = {
  reqList(params) { return post(`/adminActivitySearch`, params) }, // 活动列表
  reqDetail(params) { return post(`/activityDetail`, params) }, // 活动详情
  reqAdd(params) { return post(`/adminActivityAdd`, params) }, // 添加活动
  reqDelete(params) { return post(`/adminActivityDelete`, params) }, // 删除活动
  reqModify(params) { return post(`/adminActivityUpload`, params) }, // 修改活动
  reqUp(params) { return post(`/activityRelease`, params) }, // 活动上线
  reqDown(params) { return post(`/activityOffline`, params) }, // 活动下线
}

// 公告模块
export const Notice = {
  reqList(params) { return post(`/adminNoticeSearch`, params) }, // 公告列表
  reqDetail(params) { return post(`/noticeDetail`, params) }, // 公告详情
  reqAdd(params) { return post(`/adminNoticeAdd`, params) }, // 添加公告
  reqDelete(params) { return post(`/adminNoticeDelete`, params) }, // 删除公告
  reqModify(params) { return post(`/adminNoticeUpload`, params) }, // 修改公告
  reqUp(params) { return post(`/noticeRelease`, params) }, // 公告上线
  reqDown(params) { return post(`/noticeOffline`, params) }, // 公告下线
}

// 招聘模块
export const Recruit = {
  reqList(params) { return post(`/searchCareersList`, params) }, // 招聘列表
  reqDetail(params) { return post(`/detailAdminCareers`, params) }, // 招聘详情
  reqAdd(params) { return post(`/recruitAdd`, params) }, // 添加招聘
  reqDelete(params) { return post(`/deleteCareers`, params) }, // 招聘公告
  reqModify(params) { return post(`/editCareers`, params) }, // 招聘公告编辑
}

// 职位类型模块
export const Jobtype = {
  reqList(params) { return post(`/searchList`, params) }, // 职位类型列表
  reqDetail(params) { return post(`/searchDetail`, params) }, // 职位类型详情
  reqAdd(params) { return post(`/createDict`, params) }, // 添加职位类型
  reqModify(params) { return post(`/editDict`, params) }, // 职位类型编辑
}

//用户模块
export const User = {
  reqList(params) { return post(`/userView`, params) }, // 用户列表
  reqDetail(params) { return post(`/userDetail`, params) }, // 用户详情
  reqAdd(params) { return post(`/userAdd`, params) }, // 添加用户
  reqModify(params) { return post(`/userUpdate`, params) }, // 编辑用户
  getRoles(params) { return post(`/getRoles`, params) }, // 查询角色列表
  getRoles(params) { return post(`/getRoles`, params) },  //查询角色列表
  getOss(params) { return post(`/getOss`, params) },  //查询oss信息
}

//用户模块
export const Banner = {
  reqList(params) { return post(`/search_banner`, params) }, // 用户列表
  reqDetail(params) { return post(`/delete_banner`, params) }, // 用户详情
  reqAdd(params) { return post(`/add_banner`, params) }, // 添加用户
  reqNewsDelete(params) { return post(`/delete_banner`, params) }, // 删除新闻
  reqModify(params) { return post(`/update_banner`, params) }, // 修改活动
  reqUp(params) { return post(`/release_banner`, params) }, // 活动上线
  reqDown(params) { return post(`/offline_banner`, params) }, // 活动下线
}