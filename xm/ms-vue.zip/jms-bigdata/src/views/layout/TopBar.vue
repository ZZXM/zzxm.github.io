<template>
  <div class="topBar">
    <el-header style="height:64px;">
      <div class="header-left">
        <div class="logo-img">
          <img src="@/assets/images/logo.png" alt="极兔">
        </div>
        <div class="top-time">
          <span class="current-day">{{ week[day] }} </span>
          <span class="current-time">{{ todayData }}</span>
        </div>
      </div>
      <div class="header-action">
        <a class="personal" href="#/app/personalCenter" style="pointer-events: none;">
          <img src="@/assets/images/head.png" alt="" />
          <span class="name">{{ user.user_name }}</span>
        </a>
        <i class="iconfont icontuichu" @click="logOut">退出</i>
      </div>
    </el-header>
  </div>
</template>

<script type="text/javascript">
import { mapGetters, mapActions } from 'vuex'
import dayjs from 'dayjs';
// import * as Api from '@/api'

export default {
  name: 'TopBar',
  data() {
    return {
      week: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
      day: dayjs().day() - 1,
      todayData: dayjs().format('YYYY-MM-DD HH:mm'),
      timer: null
    };
  },
  computed: {
    ...mapGetters(['token', 'user'])
  },
  mounted() {
    const $this = this; // 声明一个变量指向Vue实例this，保证作用域一致
    this.timer = setInterval(() => {
      $this.todayData = dayjs().format('YYYY-MM-DD HH:mm'); // 修改数据date
    }, 30000)
    // console.log(dayjs().day(), 'dayjs()')
  },
  methods: {
    ...mapActions(['LOGIN_OUT']),
    /**
    * @description 退出
    */
    logOut() {
      this.$confirm('是否确认退出登录？', '', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        closeOnClickModal: false,
        type: 'warning',
        customClass: 'logout-confirm',
        confirmButtonClass: 'comfirm-btn',
        iconClass: 'el-icon-warning-outline'
      }).then(async() => {
        this.LOGIN_OUT().then(() => {
          this.$router.push({ path: '/login' })
        })
        // const res = await Api.logout()
        // if (res.code === 1) {
        //   this.LOGIN_OUT().then(() => {
        //     this.$router.push({ path: '/home' })
        // } else {
        //   this.$message.error(res.msg)
        // }
      })
    }
  },
  beforeDestroy() {
    if (this.timer) {
      clearInterval(this.timer); // 在Vue实例销毁前，清除我们的定时器
    }
  }
}
</script>

<style lang="scss" scoped>
.topBar{
  background: $-color-black;
  color: #ffffff;
  line-height: 64px;
  .header-left {
    float: left;
    display: flex;
    height: 64px;
    align-items: center;
    align-content: center;
    .logo-img {
      width: 180px;
      height: 23px;
      line-height: 23px;
      margin-left: 8px;
      -moz-user-select: none; /*火狐*/
      -webkit-user-select: none; /*webkit浏览器*/
      -ms-user-select: none; /*IE10*/
      -khtml-user-select: none; /*早期浏览器*/
      user-select: none;
      img {
        width: 100%;
        height: 100%;
      }
    }
    .top-time {
      //width: 200px;
      height: 27px;
      line-height: 27px;
      .current-day {
        margin-left: 16px;
      }
      border-left: 1px solid #FFFFFF;
      margin-left: 10px;
    }
  }
  .el-header{
    padding: 0 20px 0 12px;
  }
  .iconfont{
    font-size: 30px;
  }
  .header-action{
    float: right;
    .personal{
      text-decoration: none;
      color: white;
      margin-right: 20px;
    }
    img{
      vertical-align: middle;
      width: 28px;
      height: 28px;
    }
    .name{
      margin: 0 0 0 8px
    }
    .icontuichu{
      font-size: 14px;
      cursor: pointer;
    }
  }
}
</style>
