<template>
	<div class="layout">
		<!-- 头部 -->
		<TopBar></TopBar>
		<!-- 侧边栏 -->
		<Aside></Aside>
		<!-- main -->
		<Main></Main>
	</div>
</template>

<script type="text/javascript">
import TopBar from './TopBar'
import Aside from './Aside'
import Main from './Main'
import { mapGetters, mapActions } from 'vuex'
import debounce from 'lodash/debounce'

export default {
  name: 'Layout',
  props: {},
  components: { TopBar, Aside, Main },
  data() {
    return {
      calcHeight: 169,
      restHeight: 0,
      clientHeight: 1080
    }
  },
  computed: {
    ...mapGetters({
      tableHeight: 'tableHeight'
    })
  },
  watch: {
    $route(to, from) {
    // 设置标题
      this.$nextTick(() => {
        this.calcTableHeight()
      })
    }
  },
  created() {
  },
  mounted() {
    this.$nextTick(() => {
      this.calcTableHeight()
      // 绑定窗口resize事件
      const fn = debounce(this.calcTableHeight, 200) // 表格高度计算防抖
      window.addEventListener('resize', fn, false)
      // 触发destroyed钩子，移除resize的监听事件
      this.$once('hook:destroyed', () => {
        window.removeEventListener(
          'resize',
          debounce(this.calcTableHeight, 200),
          false
        )
      })
    })

    // 监听高度重算事件
    this.$bus.$on('doLayout', () => {
      this.$nextTick(() => this.calcTableHeight())
    })
  },
  methods: {
    ...mapActions({
      setTableHeight: 'setTableHeight'
    }),
    // 计算元素的高度用于表格自适应
    getRestHeight() {
      const arr = [
        'Title',
        'Search',
        'Pagination',
        'Menu',
        'Tip',
        'SearchExtend'
      ]
      let height = 0
      arr.forEach(function(id) {
        const els = document.querySelectorAll('#jms' + id)
        els.forEach((item) => {
          if (item.offsetParent !== null) {
            height += item.clientHeight
          }
        })
      })
      return height
    },
    calcTableHeight() {
      this.clientHeight = document.documentElement.clientHeight
      this.restHeight = this.getRestHeight()
      const tableHeight =
                this.clientHeight - this.restHeight - this.calcHeight
      this.setTableHeight(tableHeight)
    }
  }
}
</script>

<style lang="scss" scoped>
.layout {
	width: 100%;
  min-width: 1360px;
	height: 100%;
	overflow: hidden;
}
</style>
