<template>
  <div class="main">
<!--      <div class="navTab">-->
<!--           <TagBar></TagBar>-->
<!--      </div>-->
        <div class="home-container content">
              <router-view />
        </div>
  </div>
</template>

<script type="text/javascript">
export default {
  name: 'Main',
  props: {},
  data() {
    return {
    };
  }
}
</script>

<style lang="scss" scoped>
.main{
    margin-left: 200px;
    height: calc(100% - 64px);
    box-sizing: border-box;
    background: #16191C;
    padding:10px;
    .navTab{
        margin-bottom: 1px
    }
}
</style>
