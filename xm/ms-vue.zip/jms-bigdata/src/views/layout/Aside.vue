<template>
	<div class="sidebar">
		<el-menu
			:unique-opened="false"
			:default-active="defaultActiveName"
		>
			<template v-for="(item, index) in menuList">
				<!-- 没有子菜单 -->
        <!--menuMore暂时写死-->
				<el-menu-item
					:key="index"
					v-if="item.url !== menuMore && item.resource_code !== 'oss'"
					:index="item.url"
				>
					<router-link :to="{ name: item.url }">
						<i :class="[item.icon]" class="iconfont"></i>
						<span>{{ item.resource_code }}</span>
					</router-link>
				</el-menu-item>
				<!-- 有子菜单 -->
        <!--menuMore暂时写死-->
				<el-submenu
            v-if="item.children && item.url === menuMore"
					:key="index"
					:index="item.url">
					<template slot="title">
						<i :class="[item.icon]" class="iconfont"></i>
						<span>{{ item.resource_code}}</span>
					</template>
					<el-menu-item
						:key="k"
						:index="child.url"
						v-for="(child, k) in item.children">
						<router-link :to="{ name: child.url.replace('newsMaintain/', '') }">
							<span>{{ child.resource_code }}</span>
						</router-link>
					</el-menu-item>
				</el-submenu>
			</template>
		</el-menu>
	</div>
</template>

<script type="text/javascript">
import { mapGetters } from 'vuex'
export default {
  name: 'Aside',
  data() {
    return {
      menuMore: 'menuMore'
    }
  },
  computed: {
    ...mapGetters(['menu']),
    menuList() {
      return this.menu;
    },
    defaultActiveName() {
      return this.$route.name
    }
  }
}
</script>

<style lang="scss" scoped>
.sidebar {
	width: 200px;
	float: left;
	height: calc(100% - 64px);
}
</style>

<style lang="scss">
.sidebar {
	.el-menu {
		height: 100%;
    background: #16191C;
    border-right: 0;
	}
	.el-menu-item {
		position: relative;
		height: 42px;
		line-height: 42px;
		font-weight: 600;
		color: #9EA7AC;
		&.is-active {
			background: #222222;
			font-weight: 600;
			a {
				color: $-color-brand;
			}
		}
		&:hover {
			background: #222222;
		}
		a {
			position: absolute;
			top: 0;
			left: 0;
			display: block;
			width: 100%;
			height: 100%;
			color: inherit;
			text-decoration: none;
			box-sizing: border-box;
			padding-left: 12px;
			.iconfont {
				font-weight: normal;
				margin-right: 12px;
			}
		}
	}

	//有子菜单
	.el-submenu {
		.el-menu-item {
			height: 36px;
			line-height: 34px;
			font-size: 12px;
			font-weight: normal;
		}
		.el-submenu__title {
			font-weight: 600;
			height: 42px;
			line-height: 40px;
			color: #9EA7AC;
			font-size: 14px;
			padding-left: 12px !important;
			&:hover {
				background: #222;
			}
			.iconfont {
				font-weight: normal;
				margin-right: 12px !important;
			}
		}
		a {
			padding-left: 40px;
			.iconfont {
				font-size: 14px;
				margin-right: 8px;
			}
		}
		&.is-active {
			.el-submenu__title {
				color: $-color-brand;
				.iconfont,
				i.el-submenu__icon-arrow {
					color: $-color-brand;
				}
			}
		}
	}
}
</style>
