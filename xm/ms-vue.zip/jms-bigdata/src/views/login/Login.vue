<template>
  <div class="login">
    <div class="login-box">
      <div class="form">
        <h1 style="color: #FFFFFF">JMS大数据平台</h1>
      </div>
      <el-form
          ref="loginForm"
          label-position="left"
          :model="loginForm"
          :rules="rules"
          autocomplete="off"
          class="login-form">
        <el-form-item prop="account" class="loginForm-input">
          <el-input
              placeholder="请输入您的用户名"
              maxlength="12"
              v-model="loginForm.account">
            <i slot="prefix" class="iconfont iconyonghu prefix-icon"></i>
          </el-input>
        </el-form-item>
        <el-form-item prop="password" class="loginForm-input">
          <el-input
              placeholder="请输入您的密码"
              :type="isShowPassword ? 'text' : 'password'"
              maxlength="20"
              v-model="loginForm.password"
          >
            <i slot="prefix" class="iconfont iconmima prefix-icon"></i>
            <i slot="suffix" class="iconfont pointer" :class="[ isShowPassword ? 'iconkechakan':'iconbukechakan']" @click="toggleIcon"></i>
          </el-input>
        </el-form-item>
        <div class="remember">
          <el-row>
            <el-col :span="12">
              <el-checkbox
                  v-model="remember"
                  label="记住用户名"
                  class="remember-account"
              ></el-checkbox>
            </el-col>
          </el-row>
        </div>
        <div style="text-align: center">
          <el-button class="commonBtn loginBtn jt-bounce-to-right" @click.prevent="login" :loading="loginLoading">登 录</el-button>
        </div>
      </el-form>
    </div>
  </div>
</template>

<script type="text/javascript">
import { mapActions, mapGetters } from 'vuex'
import { RULES } from '@public/utils/rules'
import * as Api from '@/api'
import { Encrypt, Decrypt, sign as getSign } from '@/utils/crypto'
export default {
  name: 'Login',
  props: {},
  components: { },
  data() {
    return {
      loginForm: {
        account: '',
        password: ''
      },
      rules: {
        account: [RULES.required, RULES.chEnNumString],
        password: [RULES.required, RULES.checkPassword]
      },
      activeName: 'account',
      remember: false,
      loginLoading: false,
      isShowPassword: false, // 不显示
      appKey: '581487839',
      appSecret: 'Z3dEnV#AfN&9$IyB'
    }
  },
  computed: {
    ...mapGetters(['token'])
  },
  watch: {
  },
  created() {
    this.init()
  },
  mounted() {
  },
  methods: {
    ...mapActions(['LOGIN_INIT', 'LOGIN_OUT', 'SET_BTNLIST', 'SET_PAGELIST']),
    init() {
      // 在页面加载时从cookie获取登录信息
      const account = this.getCookie('account')
      const password = this.getCookie('password')

      // 如果存在赋值给表单，并且将记住密码勾选
      if (account) {
        this.loginForm.account = Decrypt(account)
        this.loginForm.password = Decrypt(password)
        this.remember = true
      }
    },

    toggleIcon() {
      this.isShowPassword = !this.isShowPassword
    },

    // 递归处理按钮权限
    getBtnAuth(item, name, arr = []) {
      item.forEach(item => {
        if (item.resource_type === 'BUTTON') {
          arr.push({ resource_code: item.resource_code, name })
        } else if (item.children) {
          // console.log(item, 'item')
          return this.getBtnAuth(item.children, item.url, arr)
        }
      })
      return arr
    },

    // 递归处理按钮权限 -> 暂不使用
    getPageAuth(item, arr = []) {
      item.forEach((item, index) => {
        if (item.url) {
          arr.push(item.url)
        }
        if (item.children) {
          return this.getPageAuth(item.children, arr)
        }
      })
      return arr
    },
    // 登录
    async login() {
      // const sign = getSign(postDatas, appKey, appSecret)
      this.$refs.loginForm.validate(async(valid) => {
        if (valid) {
          this.loginLoading = true
          await Api.login({ username: this.loginForm.account, password: getSign(this.loginForm.password, this.appKey, this.appSecret) })
          // const { code, data, message } = await Api.login({ username: this.loginForm.account, password: getSign(this.loginForm.password, this.appKey, this.appSecret) })
          // const { code, data, message } = await Api.login({ username: this.loginForm.account, password: this.loginForm.password })
          // const res = { code: 1, data: { token: 'qaweduiqwgeiuqwyheiuyqhwiueuywqio', name: '赵宏程' }}
          const code = 200;
          if (code === 200) {
            const data = [
              {
                'user_name': 'EVA',
                'status': 1,
                'user_id': 1,
                'token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9o',
                'menu': [
                  {
                    'resource_name': 'HOME',
                    'url': 'index',
                    'parent_id': null,
                    'resource_id': 1,
                    'resource_code': '首页',
                    'resource_type': 'MENU',
                    'user_id': 1
                  },
                  {
                    'resource_name': 'Charts',
                    'url': 'charts',
                    'parent_id': null,
                    'resource_id': 2,
                    'resource_code': '图表',
                    'resource_type': 'MENU',
                    'user_id': 1
                  },
                  {
                    'resource_name': 'Dashboards',
                    'url': 'dashboards',
                    'parent_id': null,
                    'resource_id': 3,
                    'resource_code': '图表库',
                    'resource_type': 'MENU',
                    'user_id': 1
                  },
                  {
                    'resource_name': 'Visual Analysis',
                    'url': 'visualAnalysis',
                    'parent_id': null,
                    'resource_id': 4,
                    'resource_code': '图表分析',
                    'resource_type': 'MENU',
                    'user_id': 1
                  },
                  {
                    'resource_name': 'SQL Workbench',
                    'url': 'menuMore',
                    'parent_id': null,
                    'resource_id': 5,
                    'resource_code': 'SQL工作台',
                    'resource_type': 'MENU',
                    'user_id': 1,
                    'children': [
                      {
                        'resource_name': 'SQL editor',
                        'url': 'SQLeditor',
                        'parent_id': 5,
                        'resource_id': 12,
                        'resource_code': 'SQL编辑',
                        'resource_type': 'MENU',
                        'user_id': 1
                      },
                      {
                        'resource_name': 'Saved queries',
                        'url': 'SavedQueries',
                        'parent_id': 5,
                        'resource_id': 4,
                        'resource_code': '已保存',
                        'resource_type': 'MENU',
                        'user_id': 1
                      },
                      {
                        'resource_name': 'Query history',
                        'url': 'queryHistory',
                        'parent_id': 5,
                        'resource_id': 4,
                        'resource_code': '查询历史',
                        'resource_type': 'MENU',
                        'user_id': 1
                      }
                    ]
                  },
                  {
                    'resource_name': 'Database',
                    'url': 'database',
                    'parent_id': null,
                    'resource_id': 6,
                    'resource_code': '数据库',
                    'resource_type': 'MENU',
                    'user_id': 1
                  },
                  {
                    'resource_name': 'Codeless API',
                    'url': 'codelessAPI',
                    'parent_id': null,
                    'resource_id': 7,
                    'resource_code': '低代码API',
                    'resource_type': 'MENU',
                    'user_id': 1
                  },
                  {
                    'resource_name': 'System',
                    'url': 'system',
                    'parent_id': null,
                    'resource_id': 8,
                    'resource_code': '系统设置',
                    'resource_type': 'MENU',
                    'user_id': 1
                  }
                ],
                'urls': ['index', 'charts', 'dashboards', 'visualAnalysis', 'SQLWorkbench', 'SQLeditor', 'SavedQueries', 'queryHistory', 'database', 'codelessAPI', 'system']
              }
            ]
            const { token, menu, urls } = data[0]
            this.saveAccountCookie()
            console.log(data[0], '111111')
            this.LOGIN_INIT({ user: data[0], token, menu, urls })
            // const btnList = this.getBtnAuth(menu) // 递归处理数据
            // const btnListStore = this.getuserChildMenus(btnList) // 处理格式
            // this.SET_BTNLIST(btnListStore) // 存储
            this.loginLoading = false
            this.$router.push({ name: 'index' })
          } else {
            this.loginLoading = false
            // this.$message.error(message)
          }
        }
      })
    },
    // 处理二级菜单和按钮
    getuserChildMenus(btnList) {
      let tempObj = {};
      btnList.map(item => {
        if (Object.keys(tempObj).indexOf(item.name) === -1) {
          tempObj = { ...tempObj, ...{ [item.name]: { [item.resource_code]: true }}
          }
        } else {
          tempObj[item.name] = { ...tempObj[item.name], ...{ [item.resource_code]: true }}
        }
      })
      return tempObj
    },
    recursionFun(list) {
      if (list === null) return
      const stack = [...list]
      const btnList = {}
      while (stack.length) {
        const first = stack.shift()
        const { buttons, routeName } = first
        // 按钮
        if (buttons && buttons.length) {
          btnList[routeName] = {}
          buttons.forEach(item => (btnList[routeName][item] = true))
        }
      }
      return { btnList }
    },
    // 保存用户名密码
    saveAccountCookie() {
      const { account, password } = this.loginForm
      if (this.remember) {
        this.setCookie('account', Encrypt(account), 7 * 24 * 3600)
        this.setCookie('password', Encrypt(password), 7 * 24 * 3600)
      } else {
        this.setCookie('account', '')
        this.setCookie('password', '')
      }
    },

    // 获取cookie
    getCookie(key) {
      const cookie = document.cookie
      const length = cookie.length
      if (length) {
        let start = cookie.indexOf(key + '=')
        if (start !== -1) {
          start = start + key.length + 1
          let end = cookie.indexOf(';', start)
          if (end === -1) end = length
          return unescape(cookie.substring(start, end))
        }
      }
      return ''
    },

    // 保存cookie
    setCookie(cName, value, expireseconds) {
      const exdate = new Date()
      exdate.setTime(exdate.getTime() + expireseconds * 1000)
      document.cookie = cName + '=' + escape(value) + (expireseconds == null ? '' : ';expires=' + exdate.toGMTString())
    }
  }
}
</script>

<style lang="scss">
  @import '@/assets/style/login.scss';
</style>
