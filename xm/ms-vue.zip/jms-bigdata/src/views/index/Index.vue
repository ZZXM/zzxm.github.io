<template>
  <div class="Home">
    <div class="title">欢迎来到大数据平台 - {{ name }}</div>
  </div>
</template>

<script type="text/javascript">
export default {
  name: 'App',
  data() {
    return {
      name: this.$route.name
    }
  },
  watch: {
    '$route.name': function (newVal, oldVal) {
      console.log(newVal, 'newVal')
      this.name = newVal || oldVal
    }
  },
  created() {
    const titleTexts = document.querySelectorAll('.title');
    titleTexts.forEach(titleText => {
      const letters = titleText.textContent.split('');
      titleText.textContent = '';
      letters.forEach((letter, i) => {
        const span = document.createElement('span');
        span.textContent = letter;
        span.style.animationDelay = `${i * 0.05}s`;
        titleText.append(span);
      });
    });
  }
}
</script>

<style lang="scss">
.Home{
  height: calc(100vh - 96px);
  background: #1F2327;
  border-radius: 0 0 5px 5px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
.homeImg{
  width: 585px;
  height: 392px;
  img{
    width: 100%;
    height: 100%;
  }
}
.title {
  font-size: 40px;
  font-weight: 400;
  color: #E60012;
  line-height: 56px;
  letter-spacing: 6px;
  margin-bottom: 112px;
  margin-left: -35px;
  display: flex;
  flex-wrap: wrap;
  white-space: pre;
  span {
    animation: title 0.8s ease-out both;
  }
}
@keyframes title {
  from {
    opacity: 0;
    transform: translateY(-20%);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}
}
</style>
