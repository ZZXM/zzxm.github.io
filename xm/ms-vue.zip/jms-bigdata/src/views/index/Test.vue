<template>
  <div>临时使用页面</div>
</template>

<script>
export default {
  name: 'TEST'
}
</script>

<style scoped>

</style>
