import Vue from 'vue'
import VueRouter from 'vue-router'
import store from '@/store'
import routerArr from './Router'

Vue.use(VueRouter)
const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
    return originalPush.call(this, location).catch(err => err)
}
const vm = new Vue()
const Redirect = () => import( /* webpackChunkName: "layout" */ '@/views/layout/Redirect.vue')
const routes = [
    {
        path: '/',
        redirect: '/login',
        component: () => import('@/views/login/Login.vue')
    },
    // 登录
    {
        path: '/login',
        name: 'Login',
        component: () => import('@/views/login/Login.vue')
    },
    // 刷新空白页
    {
        path: '/redirect',
        name: 'redirect',
        component: () => import('@/views/layout/Layout.vue'),
        children: [{
            path: '/redirect/:path*',
            component: Redirect
        }]
    },
    {
        path: '/app',
        redirect: '/app',
        component: () => import('@/views/layout/Layout.vue'),
        children: [
            ...routerArr
        ]
    }
]
    
const router = new VueRouter({
//   mode: 'history',
    routes
})
router.beforeEach((to, from, next) => {
    console.log(to.name, 'to.name')
    const { routeAuthList } = store.state.base
    if (store.getters.token && routeAuthList) {
        const pos = routeAuthList.indexOf(to.name) > -1
        console.log(pos, 'pos')
        // if(!pos){
        //     vm.$message.warning('没有访问该页面权限')
        //     next({name: 'index'})
        // }
        if(pos || to.name === 'index'){
            next()
        }else {
            // 判断是否重定向页 是否在路由权限列表 是否首页
            if (to.path.indexOf('/redirect') === -1 && !pos && to.name !== 'index') {
                // vm.$message.warning('没有访问该页面权限')
                next({
                    redirect: true,
                    name: 'index'
                })
            } else {
                next()
            }
        }
        //  有systemName代表不是白名单的
        next()
    } else {
        if (to.name !== 'Login') {
            next({
                name: 'Login'
            });
        }else {
           next()
        }
    }
})

export default router
