const RouterArr = [ // 首页
    {
        path: 'index',
        name: 'index',
        component: () => import('@/views/index/Index.vue'),
        meta: {
            icon: 'iconcaidan-shouye',
            title: '首页',
            affix: true
        }
    },
    // 人员管理
    {
        path: 'charts',
        name: 'charts',
        component: () => import('@/views/index/Index.vue'),
        meta: {
            icon: 'iconcaidan-shouye',
            title: '人员管理'
        }
    },
    // 人员管理
    {
        path: 'dashboards',
        name: 'dashboards',
        component: () => import('@/views/index/Index.vue'),
        meta: {
            icon: 'iconcaidan-shouye',
            title: '人员管理'
        }
    },
    // 人员管理
    {
        path: 'visualAnalysis',
        name: 'visualAnalysis',
        component: () => import('@/views/index/Index.vue'),
        meta: {
            icon: 'iconcaidan-shouye',
            title: '人员管理'
        }
    },
    //新闻站点
    {
        path: 'SQLWorkbench',
        name: 'SQLWorkbench',
        component: () => import('@/views/index/Index.vue'),
        meta: {
            icon: 'iconcaidan-baoguoguanli',
            title: '新闻动态'
        },
        children:[
            {
                path: 'SQLeditor',
                name: 'SQLeditor',
                component: () => import('@/views/index/Index.vue'),
                meta: { title: '公司新闻', keepAlive: true }
            },
            {
                path: 'SavedQueries',
                name: 'SavedQueries',
                component: () => import('@/views/index/Index.vue'),
                meta: { title: '动态新增', keepAlive: true }
            },
            {
                path: 'queryHistory',
                name: 'queryHistory',
                component: () => import('@/views/index/Index.vue'),
                meta: { title: '动态详情', keepAlive: true }
            }
        ]
    },
    // 人员管理
    {
        path: 'database',
        name: 'database',
        component: () => import('@/views/index/Index.vue'),
        meta: {
            icon: 'iconcaidan-shouye',
            title: '人员管理'
        }
    },

    // 人员管理
    {
        path: 'codelessAPI',
        name: 'codelessAPI',
        component: () => import('@/views/index/Index.vue'),
        meta: {
            icon: 'iconcaidan-shouye',
            title: '人员管理'
        }
    },

    // 人员管理
    {
        path: 'system',
        name: 'system',
        component: () => import('@/views/index/Index.vue'),
        meta: {
            icon: 'iconcaidan-shouye',
            title: '人员管理'
        }
    },
]
export default RouterArr
