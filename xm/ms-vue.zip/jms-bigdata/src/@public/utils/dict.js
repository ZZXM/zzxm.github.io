/*
 * @Author: JM
 * @Date: 2020-11-25 09:08:00
 * @Description: 自定义类型
 */


export const DICT = {
    publishStatus : [
      { value: 0, label: '待发布', name: '待发布' },
      { value: 1, label:'已发布', name: '已发布' },
      { value: 2, label:'已下线', name: '已下线' },
      { value: 3, label:'已删除', name: '已删除' }
    ],
   
  }
  