/*
* @desc 统一将同级目录的插件内置到Vue中使用
* @update --
*/
import Vue from 'vue'
const files = require.context('.', true, /\.js/)
const modules = {}

files.keys().forEach((key) => {
  if (key === './index.js') {
    return
  }
  modules[key.replace(/(^\.\/|\.js$)/g, '')] = files(key).default
})
export default {
  install() {
    for (const file of Object.values(modules)) {
      for (const item of Object.entries(file)) {
        //   框架、自定义插件引入
        if (item[0] === 'Element') {
          Vue.use(item[1], { size: 'small' })
        } else {
          Vue.use(item[1])
        }
      }
    }
  }
}
