/*
 * @Author: jinmiao
 * @Date: 2020-12-16 15:17:40
 * @Description: file content
 * @LastEditTime: 2020-12-17 10:25:14
 */
import CryptoJS from 'crypto-js'

const key = '*eRtrcGx&XueW1PFOn!%Qi9#I@0wFvOj'
const iv = '1234567812345678'

// 加密
export function Encrypt (text) {
  return CryptoJS.AES.encrypt(text, CryptoJS.enc.Utf8.parse(key), {
    iv: CryptoJS.enc.Utf8.parse(iv),
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  }).toString()
}

// 解密
export function Decrypt (text) {
  let decrypted = CryptoJS.AES.decrypt(text, CryptoJS.enc.Utf8.parse(key), {
    iv: CryptoJS.enc.Utf8.parse(iv),
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  })
  return decrypted.toString(CryptoJS.enc.Utf8)
}


// md5 加密
const md5 = str => CryptoJS.MD5(str).toString().toUpperCase()
export const sign = (params, appKey, appSecret) => {
  const obj = {}
  let str = ''
 
  for (const k in params) {
    if (['sign', 'appKey'].includes(k) || k instanceof Array || k instanceof Object || params[k] === undefined) {
      continue
    }
 
    obj[k] = params[k]
  }
 
  Object.keys(obj).sort().forEach(k => {
    str += obj[k]
  })
  str = encodeURI(`${ appKey }${ str }${ appSecret }`).toUpperCase()
  return md5(str);
}